const selector = "input";
const inputElement = document.querySelector(selector);
inputElement.focus();